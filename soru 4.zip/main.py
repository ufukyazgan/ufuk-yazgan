kelime = input("Bir sözcük yaz: ")
print(kelime[1:])