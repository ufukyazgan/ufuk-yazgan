kelime = input("Bir sözcük yaz: ")
print(kelime[0] + kelime[-1])