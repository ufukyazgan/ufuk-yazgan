kelime = input("Bir sözcük yazın: ")
harf = input("Bir harf yazın: ")
print(kelime.count(harf))