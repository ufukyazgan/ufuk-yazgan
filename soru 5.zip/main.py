kelime = input("Bir sözcük yaz: ")
sayi = int(input("Bir sayı yaz: "))
print(kelime[:sayi] + "-" + kelime[sayi:])