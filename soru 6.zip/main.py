kelime = input("Bir sözcük yaz: ")
sayi = int(input("Bir sayı yaz: "))
harf = input("Bir harf yaz: ")
kelime = kelime[:sayi] + harf + kelime[sayi+1:]
print(kelime)