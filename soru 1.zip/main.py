kelime = input("Bir sözcük yaz: ")
print(len(kelime))