import math

def koni_hacmi(r, h):

    hacim = (1/3) * math.pi * r**2 * h
    return hacim

r = float(input("Koni tabanının yarıçapını girin (cm): "))
h = float(input("Koni yüksekliğini girin (cm): "))

hacim = koni_hacmi(r, h)
print("Koninin hacmi: {:.2f} cm³".format(hacim))