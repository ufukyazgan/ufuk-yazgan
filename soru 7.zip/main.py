kelime = input("Bir sözcük yazın: ")

for harf in kelime:
    print(harf + "!")