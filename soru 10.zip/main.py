kelime = input("Bir sözcük yazın: ")
sesli_harfler = "aeıioöuüAEIİOÖUÜ"
sayac = 0

for harf in kelime:
    if harf in sesli_harfler:
        sayac += 1

print(sayac)