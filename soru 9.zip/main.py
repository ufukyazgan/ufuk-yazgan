metin = input("Bir metin yazın: ")
sozcuk = input("Bir kelime yazın: ")
yeni_metin = metin.replace(sozcuk, "")
print(yeni_metin)